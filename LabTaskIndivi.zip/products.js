let arr = [
    {
      "id": 1001,
      "subject": "Lorax",
      "description": "The Lorax is a children's book written by Dr. Seuss and first published in 1971.",
      "location": "DUBAI!",
      "price": 20.00,
      "image": "C://Users/hp/LabTaskIndivi/images/lorax.jpg",
      "availableInventory": 10,
      "rating": 2
    },
    {
      "id": 1002,
      "subject": "A Tree Is Nice Canin",
      "description": "A Tree is Nice is a children's picture book written by Janice May Udry and illustrated by Marc Simont.!",
      "location": "DUBAI!",
      "price": 11.00,
      "image": "C://Users/hp/LabTaskIndivi/images/atree.jpg",
      "availableInventory": 99,
      "rating": 4
    },
    {
      "id": 1003,
      "subject": "The Happy Day",
      "description": "The Happy Day is a 1949 picture book written by Ruth Krauss and illustrated by Marc Simont. In the book woodland creatures awake to find that it is spring.!",
      "location": "DUBAI!",
      "price": 2.99,
      "image": "C://Users/hp/LabTaskIndivi/images/happyday.jpg",
      "availableInventory": 7,
      "rating": 3
    },
    {
      "id": 1004,
      "subject": "Litte Island",
      "description": "he Little Island is a book by Margaret Wise Brown under the pseudonym Golden MacDonald and illustrated by Leonard Weisgard. !",
      "location": "DUBAI!",
      "price": 7.99,
      "image": "C://Users/hp/LabTaskIndivi/images/littleisland.jpg",
      "availableInventory": 11,
      "rating": 5
    },
    
    {
      "id": 1005,
      "subject": "Hey Al",
      "description": "Hey, Al is a book written by Arthur Yorinks and illustrated by Richard Egielski. Published by Farrar, Straus and Giroux.!",
      "location": "DUBAI!",
      "price": 49.99,
      "image": "C://Users/hp/LabTaskIndivi/images/Heyal.jpg",
      "availableInventory": 25,
      "rating": 4
    },
    {

        "id": 1006,
        "subject": "Time of Wonder",
        "description": "Time of Wonder is a 1957 children's book written and illustrated by Robert McCloskey that won the Caldecott Medal in 1958.",
        "location": "DUBAI!",
        "price": 7.99,
        "image": "C://Users/hp/LabTaskIndivi/images/timeofthewonder.jpg",
        "availableInventory": 11,
        "rating": 5
      },
      {
        "id": 1007,
        "subject": "Burt Dow",
        "description": "Burt Dow, Deep-water Man Book by Robert McCloskey",
        "location": "AJMAN",
        "price": 7.99,
        "image": "C://Users/hp/LabTaskIndivi/images/burndown.jpg",
        "availableInventory": 11,
        "rating": 5
      },
      {
        "id": 1008,
        "subject": "Hamlet",
        "description": "by William Shakespeare, Harold Bloom (Contributor), Rex Gibson (Editor)!",
        "location": "SHARJA!",
        "price": 7.99,
        "image": "C://Users/hp/LabTaskIndivi/images/hamlet.jpg",
        "availableInventory": 11,
        "rating": 5
      },
      {
        "id": 1009,
        "subject": "Things in Jars",
        "description": "Jess Kidd (author)1st paper backed Paperback (02 Jan 2020)!",
        "location": "ALAIN",
        "price": 7.99,
        "image": "C://Users/hp/LabTaskIndivi/images/thingsinjars.jpg",
        "availableInventory": 11,
        "rating": 5
      },
      {
        "id": 1010,
        "subject": "Don't Let the Pigeon Drive the Bus!",
        "description": "Don't Let the Pigeon Drive the Bus! is a children's picture book by Mo Willems.!",
        "location": "AJMAN",
        "price": 7.99,
        "image": "C://Users/hp/LabTaskIndivi/images/pigeondrive.jpg",
        "availableInventory": 11,
        "rating": 5
      }
  ]